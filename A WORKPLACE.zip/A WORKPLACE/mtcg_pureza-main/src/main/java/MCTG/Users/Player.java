package MCTG.Users;

public class Player {
    private String username;

    public String getUsername() {
        return username;
    }

}
